#include <stdio.h>
#include <stdlib.h>

int main()
{

    for(int i=1; i<=20; i++)
        printf("Esta e a mensagem %d\n", i);

    return 0;
}
