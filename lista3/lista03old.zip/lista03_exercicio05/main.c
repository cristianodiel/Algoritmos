/*Escreva um algoritmo que leia 10 n�meros informados pelo usu�rio e calcule a soma desses
n�meros*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n=10,i=1;
    char nome[40];
    printf("Algoritmo para calcular a soma de 10 numeros\n");

    while (i<n)
    {
        printf("Insira x%i\n", nome);
        scanf("%s",&nome);
        i++;

    }

    return 0;
}
