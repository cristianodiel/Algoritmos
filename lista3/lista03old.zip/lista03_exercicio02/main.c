#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num1, num2;
    int resultado=0;

    printf("Digite o primeiro (menor) numero do intervalo: ");
    scanf("%d", &num1);
    printf("Digite o segundo (maior) numero do intervalo: ");
    scanf("%d", &num2);

    int contador=0;
    contador = num1;

    while(contador<=num2)
    {
        num1+=(num1+1);
        contador+1;
    }

    printf("Resultado: %d\n", num1);

    return 0;
}
